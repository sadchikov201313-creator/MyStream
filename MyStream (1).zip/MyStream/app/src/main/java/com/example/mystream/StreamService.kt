package com.example.mystream

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.pedro.common.ConnectChecker
import com.pedro.library.rtmp.RtmpDisplay

class StreamService : Service() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        const val ACTION_MIC_ON = "mic_on"
        const val ACTION_MIC_OFF = "mic_off"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_URL = "url"
        private const val CHANNEL = "stream"
    }

    private var display: RtmpDisplay? = null
    private val ui = Handler(Looper.getMainLooper())

    private val checker = object : ConnectChecker {
        override fun onConnectionStarted(url: String) {}
        override fun onConnectionSuccess() {
            StreamState.set(Phase.LIVE)
            toast("Эфир идёт")
        }
        override fun onConnectionFailed(reason: String) {
            toast("Ошибка подключения: $reason")
            ui.post { stopAll() }
        }
        override fun onNewBitrate(bitrate: Long) {}
        override fun onDisconnect() {
            StreamState.set(Phase.IDLE)
        }
        override fun onAuthError() {
            toast("Ошибка авторизации (проверь ключ)")
        }
        override fun onAuthSuccess() {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startStreaming(intent)
            ACTION_STOP -> stopAll()
            ACTION_MIC_ON -> display?.enableAudio()
            ACTION_MIC_OFF -> display?.disableAudio()
        }
        return START_NOT_STICKY
    }

    private fun startStreaming(intent: Intent) {
        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val url = intent.getStringExtra(EXTRA_URL) ?: return
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) { stopAll(); return }

        StreamState.set(Phase.CONNECTING)
        // Сначала foreground-уведомление, потом захват экрана (требование Android 14)
        showForeground()

        val m = resources.displayMetrics
        val shortSide = Prefs.resolution(this)
        val longSide = (shortSide * maxOf(m.widthPixels, m.heightPixels).toFloat() /
            minOf(m.widthPixels, m.heightPixels)).toInt() / 2 * 2
        val landscape = Prefs.orientation(this) == 1
        val w = if (landscape) longSide else shortSide
        val h = if (landscape) shortSide else longSide

        val d = RtmpDisplay(applicationContext, true, checker)
        d.setIntentResult(code, data)
        if (d.prepareVideo(w, h, Prefs.fps(this), Prefs.bitrate(this) * 1000, 0, m.densityDpi) &&
            d.prepareAudio()
        ) {
            display = d
            d.startStream(url)
            if (!StreamState.micOn) d.disableAudio()
        } else {
            toast("Не удалось подготовить кодеки")
            stopAll()
        }
    }

    private fun showForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Стрим", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("MyStream")
            .setContentText("Идёт трансляция экрана")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                1, n,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(1, n)
        }
    }

    private fun stopAll() {
        display?.let { if (it.isStreaming) it.stopStream() }
        display = null
        StreamState.set(Phase.IDLE)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun toast(text: String) {
        ui.post { Toast.makeText(applicationContext, text, Toast.LENGTH_SHORT).show() }
    }

    override fun onDestroy() {
        display?.let { if (it.isStreaming) it.stopStream() }
        super.onDestroy()
    }
}
