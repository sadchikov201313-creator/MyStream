package com.example.mystream

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.pedro.common.ConnectChecker
import com.pedro.library.rtmp.RtmpDisplay

class StreamService : Service() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_URL = "url"
        private const val CHANNEL = "stream"
    }

    private var display: RtmpDisplay? = null
    private val ui = Handler(Looper.getMainLooper())

    private val checker = object : ConnectChecker {
        override fun onConnectionStarted(url: String) {}
        override fun onConnectionSuccess() = toast("Эфир идёт")
        override fun onConnectionFailed(reason: String) {
            toast("Ошибка подключения: $reason")
            ui.post { stopAll() }
        }
        override fun onNewBitrate(bitrate: Long) {}
        override fun onDisconnect() = toast("Эфир остановлен")
        override fun onAuthError() = toast("Ошибка авторизации (проверь ключ)")
        override fun onAuthSuccess() {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startStreaming(intent)
            ACTION_STOP -> stopAll()
        }
        return START_NOT_STICKY
    }

    private fun startStreaming(intent: Intent) {
        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val url = intent.getStringExtra(EXTRA_URL) ?: return
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) { stopAll(); return }

        // Сначала foreground-уведомление, потом захват экрана (требование Android 14)
        showForeground()

        val m = resources.displayMetrics
        val scale = 720f / minOf(m.widthPixels, m.heightPixels)
        val w = (m.widthPixels * scale).toInt() / 2 * 2
        val h = (m.heightPixels * scale).toInt() / 2 * 2

        val d = RtmpDisplay(applicationContext, true, checker)
        d.setIntentResult(code, data)
        if (d.prepareVideo(w, h, 30, 3_000_000, 0, m.densityDpi) && d.prepareAudio()) {
            display = d
            d.startStream(url)
        } else {
            toast("Не удалось подготовить кодеки")
            stopAll()
        }
    }

    private fun showForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Стрим", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("MyStream")
            .setContentText("Идёт трансляция экрана")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                1, n,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(1, n)
        }
    }

    private fun stopAll() {
        display?.let { if (it.isStreaming) it.stopStream() }
        display = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun toast(text: String) {
        ui.post { Toast.makeText(applicationContext, text, Toast.LENGTH_SHORT).show() }
    }

    override fun onDestroy() {
        display?.let { if (it.isStreaming) it.stopStream() }
        super.onDestroy()
    }
}
