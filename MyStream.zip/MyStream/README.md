# MyStream — этап 1
Трансляция экрана Android + микрофон по RTMP (Twitch / YouTube / Facebook / свой сервер).

Запуск: Android Studio -> Open -> папка MyStream -> дождаться Gradle sync -> Run на телефоне.
Twitch: URL rtmp://live.twitch.tv/app, ключ из Creator Dashboard -> Settings -> Stream.
YouTube: URL rtmp://a.rtmp.youtube.com/live2, ключ из YouTube Studio.
