package com.example.mystream

import android.Manifest
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var urlInput: EditText
    private lateinit var keyInput: EditText

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                val url = urlInput.text.toString().trim().trimEnd('/') + "/" +
                    keyInput.text.toString().trim()
                val i = Intent(this, StreamService::class.java).apply {
                    action = StreamService.ACTION_START
                    putExtra(StreamService.EXTRA_CODE, result.resultCode)
                    putExtra(StreamService.EXTRA_DATA, data)
                    putExtra(StreamService.EXTRA_URL, url)
                }
                ContextCompat.startForegroundService(this, i)
            } else {
                Toast.makeText(this, "Захват экрана не разрешён", Toast.LENGTH_SHORT).show()
            }
        }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
            if (grants[Manifest.permission.RECORD_AUDIO] == true) {
                val mpm = getSystemService(MediaProjectionManager::class.java)
                projectionLauncher.launch(mpm.createScreenCaptureIntent())
            } else {
                Toast.makeText(this, "Нужен доступ к микрофону", Toast.LENGTH_SHORT).show()
            }
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        urlInput = EditText(this).apply {
            hint = "RTMP URL, например rtmp://live.twitch.tv/app"
            setText("rtmp://live.twitch.tv/app")
            setSingleLine()
        }
        keyInput = EditText(this).apply {
            hint = "Stream key"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val start = Button(this).apply {
            text = "Начать эфир"
            setOnClickListener {
                if (keyInput.text.isBlank()) {
                    Toast.makeText(this@MainActivity, "Введи stream key", Toast.LENGTH_SHORT).show()
                } else {
                    val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
                    if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
                    permissionLauncher.launch(perms.toTypedArray())
                }
            }
        }
        val stop = Button(this).apply {
            text = "Остановить"
            setOnClickListener {
                startService(Intent(this@MainActivity, StreamService::class.java).apply {
                    action = StreamService.ACTION_STOP
                })
            }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(48), dp(20), dp(20))
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            addView(urlInput, lp)
            addView(keyInput, lp)
            addView(start, lp)
            addView(stop, lp)
        }
        setContentView(root)
    }
}
