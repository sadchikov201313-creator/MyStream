package com.example.mystream

import android.app.AlertDialog
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.activity.ComponentActivity

class SettingsActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Theme.BG
        window.navigationBarColor = Theme.BG

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(36), dp(20), dp(28))
        }

        col.addView(label("← Назад", 16f, Theme.ACCENT).apply {
            setPadding(0, dp(8), dp(12), dp(8))
            setOnClickListener { finish() }
        })
        col.addView(label("Настройки", 28f, bold = true), lp(8))

        val video = card()
        video.addView(label("Видео", 14f, Theme.MUTED), lp(0))

        addRow(
            video, "Разрешение",
            Prefs.RES.map { "${it}p" },
            { Prefs.RES.indexOf(Prefs.resolution(this)).coerceAtLeast(0) }
        ) { Prefs.setInt(this, "res", Prefs.RES[it]) }

        addRow(
            video, "Частота кадров",
            Prefs.FPS.map { "$it" },
            { Prefs.FPS.indexOf(Prefs.fps(this)).coerceAtLeast(0) }
        ) { Prefs.setInt(this, "fps", Prefs.FPS[it]) }

        addRow(
            video, "Битрейт",
            Prefs.BITRATE.map { "$it кбит/с" },
            { Prefs.BITRATE.indexOf(Prefs.bitrate(this)).coerceAtLeast(0) }
        ) { Prefs.setInt(this, "bitrate", Prefs.BITRATE[it]) }

        col.addView(video, lp(20))
        col.addView(
            label("Чтобы настройки заработали, перезапусти эфир.", 13f, Theme.MUTED),
            lp(10)
        )

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Theme.BG)
            isFillViewport = true
            addView(col)
        })
    }

    private fun addRow(
        parent: LinearLayout,
        title: String,
        names: List<String>,
        selected: () -> Int,
        onPick: (Int) -> Unit
    ) {
        val value = label(names[selected()], 16f, Theme.ACCENT)
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(14), 0, dp(14))
            addView(
                label(title, 16f),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            addView(value)
            setOnClickListener {
                AlertDialog.Builder(this@SettingsActivity)
                    .setTitle(title)
                    .setSingleChoiceItems(names.toTypedArray(), selected()) { d, which ->
                        onPick(which)
                        value.text = names[which]
                        d.dismiss()
                    }
                    .show()
            }
        }
        parent.addView(row, lp(0))
    }
}
