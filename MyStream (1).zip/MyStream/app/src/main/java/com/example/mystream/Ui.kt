package com.example.mystream

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.rounded(color: Int, radiusDp: Int = 16): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

fun Context.label(
    content: String,
    sizeSp: Float = 16f,
    color: Int = Theme.TEXT,
    bold: Boolean = false
): TextView = TextView(this).apply {
    text = content
    textSize = sizeSp
    setTextColor(color)
    if (bold) setTypeface(typeface, Typeface.BOLD)
}

fun Context.card(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    background = rounded(Theme.CARD)
    setPadding(dp(16), dp(14), dp(16), dp(14))
}

fun Context.lp(topDp: Int = 14): LinearLayout.LayoutParams =
    LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(topDp) }

fun Context.pill(content: String, filled: Boolean): Button = Button(this).apply {
    text = content
    isAllCaps = false
    textSize = 16f
    setTextColor(if (filled) Color.WHITE else Theme.ACCENT)
    background = rounded(if (filled) Theme.ACCENT else Theme.CARD_ALT, 28)
}

fun Context.input(hintText: String, value: String, secret: Boolean = false): EditText =
    EditText(this).apply {
        hint = hintText
        setText(value)
        setSingleLine()
        setTextColor(Theme.TEXT)
        setHintTextColor(Theme.MUTED)
        background = rounded(Theme.CARD_ALT, 12)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        inputType = if (secret) {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        } else {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
    }
