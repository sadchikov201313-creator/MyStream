package com.example.mystream

import android.content.Context

object Prefs {
    val RES = listOf(480, 720, 1080)
    val FPS = listOf(30, 60)
    val BITRATE = listOf(2500, 4000, 6000, 9000)

    private fun sp(c: Context) = c.getSharedPreferences("mystream", Context.MODE_PRIVATE)

    fun url(c: Context): String = sp(c).getString("url", "rtmp://live.twitch.tv/app") ?: ""
    fun key(c: Context): String = sp(c).getString("key", "") ?: ""
    fun saveServer(c: Context, url: String, key: String) {
        sp(c).edit().putString("url", url).putString("key", key).apply()
    }

    fun resolution(c: Context): Int = sp(c).getInt("res", 720)
    fun fps(c: Context): Int = sp(c).getInt("fps", 30)
    fun bitrate(c: Context): Int = sp(c).getInt("bitrate", 4000)
    fun orientation(c: Context): Int = sp(c).getInt("orient", 0) // 0 вертикально, 1 горизонтально

    fun setInt(c: Context, name: String, v: Int) {
        sp(c).edit().putInt(name, v).apply()
    }
}
