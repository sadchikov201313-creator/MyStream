package com.example.mystream

import android.os.Handler
import android.os.Looper
import android.os.SystemClock

enum class Phase { IDLE, CONNECTING, LIVE }

object StreamState {
    @Volatile var phase: Phase = Phase.IDLE
    @Volatile var liveSince: Long = 0L
    @Volatile var micOn: Boolean = true
    var listener: (() -> Unit)? = null

    private val ui = Handler(Looper.getMainLooper())

    fun set(p: Phase) {
        ui.post {
            phase = p
            if (p == Phase.LIVE) liveSince = SystemClock.elapsedRealtime()
            listener?.invoke()
        }
    }
}
