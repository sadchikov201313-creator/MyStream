# MyStream — этап 2
Трансляция экрана Android + микрофон по RTMP (Twitch / YouTube / Facebook / свой сервер).
Экраны: главный (статус эфира, сервер и ключ, микрофон, ориентация) и настройки (разрешение, fps, битрейт).

Twitch: URL rtmp://live.twitch.tv/app, ключ из Creator Dashboard -> Settings -> Stream.
YouTube: URL rtmp://a.rtmp.youtube.com/live2, ключ из YouTube Studio.
