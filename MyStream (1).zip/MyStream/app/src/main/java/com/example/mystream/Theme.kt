package com.example.mystream

object Theme {
    val BG = 0xFF121016.toInt()
    val CARD = 0xFF1E1B26.toInt()
    val CARD_ALT = 0xFF2A2634.toInt()
    val ACCENT = 0xFF9B7BFF.toInt()
    val TEXT = 0xFFFFFFFF.toInt()
    val MUTED = 0xFF8E8A9A.toInt()
    val LIVE = 0xFFE5484D.toInt()
}
