package com.example.mystream

import android.Manifest
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Chronometer
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var urlInput: EditText
    private lateinit var keyInput: EditText
    private lateinit var status: TextView
    private lateinit var timer: Chronometer
    private lateinit var info: TextView
    private lateinit var actionBtn: Button
    private lateinit var segment: LinearLayout

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                val url = urlInput.text.toString().trim().trimEnd('/') + "/" +
                    keyInput.text.toString().trim()
                val i = Intent(this, StreamService::class.java).apply {
                    action = StreamService.ACTION_START
                    putExtra(StreamService.EXTRA_CODE, result.resultCode)
                    putExtra(StreamService.EXTRA_DATA, data)
                    putExtra(StreamService.EXTRA_URL, url)
                }
                ContextCompat.startForegroundService(this, i)
            } else {
                Toast.makeText(this, "Захват экрана не разрешён", Toast.LENGTH_SHORT).show()
            }
        }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
            if (grants[Manifest.permission.RECORD_AUDIO] == true) {
                val mpm = getSystemService(MediaProjectionManager::class.java)
                projectionLauncher.launch(mpm.createScreenCaptureIntent())
            } else {
                Toast.makeText(this, "Нужен доступ к микрофону", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Theme.BG
        window.navigationBarColor = Theme.BG

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(36), dp(20), dp(28))
        }

        // Шапка
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(
            label("MyStream", 26f, bold = true),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        header.addView(label("Настройки", 16f, Theme.ACCENT).apply {
            setPadding(dp(12), dp(8), dp(4), dp(8))
            setOnClickListener {
                startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
            }
        })
        col.addView(header, lp(0))

        // Статус эфира
        status = label("Не в эфире", 22f, Theme.MUTED, true).apply { gravity = Gravity.CENTER }
        timer = Chronometer(this).apply {
            textSize = 34f
            setTextColor(Theme.TEXT)
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        info = label("", 13f, Theme.MUTED).apply { gravity = Gravity.CENTER }
        val preview = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(Theme.CARD, 20)
            setPadding(dp(16), dp(32), dp(16), dp(32))
            addView(status, lp(0))
            addView(timer, lp(6))
            addView(info, lp(8))
        }
        col.addView(preview, lp(20))

        // Сервер
        urlInput = input("Сервер (RTMP URL)", Prefs.url(this))
        keyInput = input("Ключ трансляции", Prefs.key(this), secret = true)
        col.addView(card().apply {
            addView(label("Сервер", 14f, Theme.MUTED), lp(0))
            addView(urlInput, lp(8))
            addView(keyInput, lp(8))
        }, lp(14))

        // Звук
        val mic = Switch(this).apply {
            text = "Микрофон"
            textSize = 16f
            setTextColor(Theme.TEXT)
            isChecked = StreamState.micOn
            setOnCheckedChangeListener { _, on ->
                StreamState.micOn = on
                if (StreamState.phase != Phase.IDLE) {
                    startService(
                        Intent(this@MainActivity, StreamService::class.java)
                            .setAction(
                                if (on) StreamService.ACTION_MIC_ON else StreamService.ACTION_MIC_OFF
                            )
                    )
                }
            }
        }
        col.addView(card().apply {
            addView(label("Звук", 14f, Theme.MUTED), lp(0))
            addView(mic, lp(8))
        }, lp(14))

        // Ориентация
        segment = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buildSegment()
        col.addView(card().apply {
            addView(label("Ориентация", 14f, Theme.MUTED), lp(0))
            addView(segment, lp(8))
            addView(
                label("Для игр в горизонтальном режиме выбери «Горизонтально». Применяется при следующем запуске.", 12f, Theme.MUTED),
                lp(8)
            )
        }, lp(14))

        // Кнопка эфира
        actionBtn = pill("Начать эфир", true).apply {
            textSize = 18f
            setOnClickListener { onAction() }
        }
        col.addView(
            actionBtn,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)).apply {
                topMargin = dp(24)
            }
        )

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Theme.BG)
            isFillViewport = true
            addView(col)
        })
    }

    private fun buildSegment() {
        segment.removeAllViews()
        val selected = Prefs.orientation(this)
        listOf("Вертикально", "Горизонтально").forEachIndexed { i, name ->
            val b = pill(name, i == selected).apply {
                setOnClickListener {
                    Prefs.setInt(this@MainActivity, "orient", i)
                    buildSegment()
                }
            }
            segment.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                if (i == 0) rightMargin = dp(8)
            })
        }
    }

    private fun onAction() {
        if (StreamState.phase != Phase.IDLE) {
            startService(
                Intent(this, StreamService::class.java).setAction(StreamService.ACTION_STOP)
            )
            return
        }
        if (keyInput.text.isBlank()) {
            Toast.makeText(this, "Введи ключ трансляции", Toast.LENGTH_SHORT).show()
            return
        }
        Prefs.saveServer(this, urlInput.text.toString().trim(), keyInput.text.toString().trim())
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        permissionLauncher.launch(perms.toTypedArray())
    }

    private fun refresh() {
        when (StreamState.phase) {
            Phase.IDLE -> {
                status.text = "Не в эфире"
                status.setTextColor(Theme.MUTED)
                timer.stop()
                timer.visibility = View.GONE
                actionBtn.text = "Начать эфир"
            }
            Phase.CONNECTING -> {
                status.text = "Подключение…"
                status.setTextColor(Theme.ACCENT)
                timer.stop()
                timer.visibility = View.GONE
                actionBtn.text = "Остановить"
            }
            Phase.LIVE -> {
                status.text = "В ЭФИРЕ"
                status.setTextColor(Theme.LIVE)
                timer.base = StreamState.liveSince
                timer.visibility = View.VISIBLE
                timer.start()
                actionBtn.text = "Остановить"
            }
        }
        info.text = "${Prefs.resolution(this)}p • ${Prefs.fps(this)} fps • ${Prefs.bitrate(this)} кбит/с"
    }

    override fun onStart() {
        super.onStart()
        StreamState.listener = { refresh() }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onStop() {
        StreamState.listener = null
        super.onStop()
    }
}
